<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;

/**
 * Site controller
 */
class GoController extends Controller
{
	public $enableCsrfValidation = false;
	//上传数据并保存在数据库中
	public function actionImplod(){
		$tmp_name=$_FILES['excel']['tmp_name'];//临时的文件路径
		$name=$_FILES['excel']['name'];//上传的文件的名字
		$res=move_uploaded_file ( $tmp_name ,  "../upload/$name" );
		$title=Yii::$app->request->post('title');//接收后台传过来的单元
		$month=Yii::$app->request->post('month');
		require(__DIR__ . '/../../common/Classes/PHPExcel.php');//引用PHPExcel

		// $excel=new \PHPExcel;

		$objPHPExcel = \PHPExcel_IOFactory::load("../upload/$name"); //查找要操作的Excel文件
		$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);//把数据转换成数组的形式
		unset($sheetData[1]);//去掉数组中的第一的下标的值

		$type=array_flip(Yii::$app->params['type']);//让他的类型转换位置(下标和值)
		$sorce=Yii::$app->params['sorce'];//查找各个题型的分数值
		// var_dump($type);exit;
		foreach ($sheetData as $key => $val) {
			$array=array(
				'title'=>$val['C'],//试题的名称
				'month'=>$month,//试题的月份 
				'danyuan'=>$title,//单元的名字
				'type'=>$type[$val['B']],//题目的类型
				'time'=>date("Y-m-d",time()),//添加的时间
				'num'=>$sorce[$type[$val['B']]],//试题的分数
				'name'=>$val['L']//出题人
			);

			$r=Yii::$app->db->createCommand()->insert('timu',$array)->execute();//入库

			$tid=Yii::$app->db->getLastInsertID();//查到库中的最后一条的id

			//题号
			$th=array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

			$yes=str_split($val['J'],1);//该题目的正确的答案

			for($i='D';$i<='I';$i++){
				if(empty($val[$i])) continue;

				$is_true=in_array($th[$i],$yes)? 1 : 0;

				$arr=array(
					'tm_id'=>$tid,
					'options'=>$val[$i],
					'is_true'=>$is_true
				);
				$re=Yii::$app->db->createCommand()->insert('daan',$arr)->execute();
			}

		}
	
		if($r && $re){
			echo "导入成功";exit;
		}
	}

	//查找到数据库中所有值
	public function actionShow(){
		$sql="select * from timu";
		$re=Yii::$app->db->createCommand($sql)->queryAll();
		//总条数
		$count=count($re);
		//当前页
		$page=Yii::$app->request->get('page',1);
		// echo $page;exit;
		//每页显示的条数
		$size=Yii::$app->request->get('size',5);
		//偏移量
		$limit=($page-1)*$size;
		//查询当前页的数据
		$sql="select * from timu limit ".$limit.",".$size."";
		$arr=Yii::$app->db->createCommand($sql)->queryAll();
		//页面数据的页码开始位置
		$start=$page-3;
		if($start<1) $start=1;
		//总页数
		$total=ceil($count/$size);
		//页面数据的页码结束位置
		$end=$start+6;
		if($end>$total) $end=$total;

		$str = '<ul class="pagination">';

		for($i=$start;$i<=$end;$i++){
			if($page==$i){
				$str.='<li class="active"><a href="javascript:void(0)" atr="'.$i.'" class="page">'.$i.'</a></li>';
			}else{
				$str.='<li><a href="javascript:void(0)" atr="'.$i.'" class="page">'.$i.'</a></li>';
			}
		}
		$str.='</ul>';

		// var_dump($arr);exit;
		if($arr){
			$t=array(
				'data'=>$arr,
				'str'=>$str
			);
			$s=json_encode($t);
			echo $s;exit;
		}
	}


}