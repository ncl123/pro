<?php
namespace frontend\controllers;

use Yii;
use yii\web\Controller;

/**
 * Site controller
 */
class GoController extends Controller
{
	public function actionIndex(){
		echo 123;exit;	
	}
}