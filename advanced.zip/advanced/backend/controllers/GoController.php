<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use common\Classes\curl;

/**
 * Site controller
 */
class GoController extends Controller
{
	public $enableCsrfValidation = false;
	public function actionSt(){

		$url="http://47.93.198.68/yiinew/api/web/index.php?r=go/show";
		$reg=curl::_get($url);
		
		header('content-type:text/html;charset=utf-8');
		$s=json_decode($reg,true);
		return $this->render('index',['data'=>$s['data'],'str'=>$s['str']]);exit;

	
	}
	public function actionTz(){
		return $this->render('add');
	}
	public function actionGetinfo(){
		header('content-type:text/html;charset=utf-8');
		if(Yii::$app->request->isPost){
			$tmp_name=$_FILES['img']['tmp_name'];//临时的文件路径
			$name=$_FILES['img']['name'];//上传的文件的名字
			$res=move_uploaded_file ( $tmp_name ,  "../upload/$name" );
			if($res){
				$url="http://47.93.198.68/yiinew/api/web/index.php?r=go/implod";//api的接口地址
				$param['title']=Yii::$app->request->post('names');//传过来的单元的名称
				$param['month']=Yii::$app->request->post('month');
				$file['excel']="../upload/$name";
				$reg=curl::_post($url,$param,$file);
				if($reg == '导入成功'){
					$this->redirect('index.php?r=go/st');
				}
			}
		}else{
			return $this->render('add');
		}

	}

	public function actionSc(){
		return $this->render('sheng');
	}
}