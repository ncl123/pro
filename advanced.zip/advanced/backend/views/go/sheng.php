<style type="text/css">
	.tj{
    float:right;
  }
</style>

<ul class="breadcrumb">
    <li><a href="#">考试管理</a></li>
    <li class="active">试题生成</li>
</ul>
<form action="index.php?r=go/st" method="post">
  <button type="submit" class="btn btn-primary tj">试题列表</button>
</form>

<form action="index.php?r=go/list" method="post">
<?php foreach(Yii::$app->params['month'] as $k=>$v){?>
  <input type="checkbox" name=""><b><?=$v?></b></br>
    <?php foreach(Yii::$app->params['unit'] as $key=>$val){
        if($key % 10 ==0) echo "</br>"
      ?>
      <input type="checkbox" name="unit[<?=$k?>][]" value="<?=$key;?>"><?=$val?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php } ?></br></br>
<?php } ?>
<button type="submit" class="btn btn-default">提交</button>

</form>