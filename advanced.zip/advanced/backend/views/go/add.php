<style type="text/css">
	.tj{
		float:right;
	}
</style>
<div>
<ul class="breadcrumb">
    <li><a href="#">考试管理</a></li>
    <li class="active">试题添加</li>
</ul>
<form action="index.php?r=go/st" method="post">
	<button type="submit" class="btn btn-primary tj">试题列表</button>
</form>
</div>
<br>
<div>
<form role="form" action='index.php?r=go/getinfo' method="post" enctype='multipart/form-data'>
  <div class="form-group">

    <label for="name">月份</label>
    <select class="form-control" name="month">
      <option>请选择</option>
      <?php foreach(Yii::$app->params['month'] as $k=>$v){?>
        <option value="<?=$k;?>"><?=$v;?></option>
      <?php }?>
    </select>

    <label for="name">单元</label>
    <select class="form-control" name='names'>
      <option>请选择</option>
      <?php foreach(Yii::$app->params['unit'] as $k=>$v){?>
        <option value="<?=$v?>"><?=$v?></option>
      <?php }?>
    </select>
  </div>
  <div class="form-group">
    <label for="inputfile">试题导入</label>
    <input type="file" id="inputfile" name="img">
  </div>
  <button type="submit" class="btn btn-default">提交</button>
</form>
</div>