<style type="text/css">
	.tj{
    float:right;
  }

  .tl{
    float:right;
    margin-right: 15px;
  }
</style>

<ul class="breadcrumb">
    <li><a href="#">考试管理</a></li>
    <li class="active">试题列表</li>
</ul>
<form action="index.php?r=go/tz" method="post">
  <button type="submit" class="btn btn-primary tj">试题添加</button>
</form>

    
<form action="index.php?r=go/sc" method="post">
  <button type="submit" class="btn btn-info tl">生成试题</button> 
</form>

<table class="table table-bordered">
  <caption>试题列表布局</caption>
  <thead>
    <tr>
      <th>题干</th>
      <th>月份</th>
      <th>单元</th>
      <th>题型</th>
      <th>分值</th>
      <th>时间</th>
      <th>操作</th>
    </tr>
  </thead>
  <tbody>
  	<?php if(!empty($data)) foreach($data as $k=>$v){?>
    <tr>
      <td><?=$v['title']?></td>
      <td><?=$v['month']?></td>
      <td><?=$v['danyuan']?></td>
      <?php if($v['type']=="p-1"){?>
      	<td>单选题</td>
      <?php }elseif($v['type']=="p-2"){?>
		<td>多选题</td>
      <?php }else{?>
      	<td>判断题</td>
      <?php }?>
      <td><?=$v['num']?></td>
      <td><?=$v['time']?></td>
      <td>
      	<button type="button" class="btn btn-danger">删除</button>
      	<button type="button" class="btn btn-info">修改</button>
      </td>
    </tr>
	<?php } ?>
  </tbody>
</table>
<div id="page">
	<?=$str?>
</div>
<script src="../jquery12.js"></script>
<script type="text/javascript">
	var obj=new Object();
  $(document).on('click','.page',function(){
  	var p=$(this).attr('atr');
  	getdata(p);
  })


  function getdata(p){
  	obj['page']=p;
  	$.ajax({
  		url:"http://47.93.198.68/yiinew/api/web/index.php?r=go/show",
  		data:obj,
  		dataType:'json',
  		success:function(e){
  			// console.log(e)
  			var str='';
  			$.each(e.data,function(k,v){

  				var type='单选题';
  				if(v.type=='p-2'){
  					type='多选题'
  				}else if(v.type=='p-0'){
  					type='判断题'
  				}

  				str+='<tr>'
  				str+='<td>'+v.title+'</td>'
  				str+='<td>'+v.month+'</td>'
  				str+='<td>'+v.danyuan+'</td>'
  				str+='<td>'+type+'</td>'
  				str+='<td>'+v.num+'</td>'
                str+='<td>'+v.time+'</td>'
                str+='<td>'
                str+='<button type="button" class="btn btn-danger">删除</button>'
                str+='<button type="button" class="btn btn-info">修改</button>'
                str+='</td>'
  			})

  			$('tbody').html(str)
  			$('#page').html(e.str)
  		}
  	})
  }
</script>